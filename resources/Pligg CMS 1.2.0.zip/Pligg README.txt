---------------------------------------------------------------
  Release
---------------------------------------------------------------

   We proudly present Pligg CMS 1.2.0
   Released September 18, 2011 21:40 EST
   SVN Build: 2399

---------------------------------------------------------------
  Installation and Upgrading
---------------------------------------------------------------

   Please see the readme.html file included with the release for 
   the most up to date and detailed instructions for installing 
   and upgrading Pligg.

---------------------------------------------------------------
  CHANGELOG
---------------------------------------------------------------

   This update addresses security issues, adds a few smaller 
   features, takes some steps to optimize code, and adds
   some older phrases that were previously left out of the 
   language file.
   
---------------------------------------------------------------
  Links
---------------------------------------------------------------

   Homepage : http://www.pligg.com/
   Forums : http://forums.pligg.com/
   Donate : http://forums.pligg.com/donate/
   Gallery : http://www.pligg.com/gallery/
   Shop : http://www.pligg.com/pro/
   Freelance Job Opportunties : http://www.pligg.com/employment/
   Blog : http://www.pligg.com/blog/

---------------------------------------------------------------
  License
---------------------------------------------------------------

	Pligg is an open source project and is licensed under the 
	Affero General Public License. Please read the full license at:
	http://www.affero.org/oagpl.html
