﻿<?php
	$module_info['name'] = 'Simple Private Messaging';
	$module_info['desc'] = 'Let users send private messages to each other.';
	$module_info['version'] = 0.7;
	$module_info['update_url'] = 'http://forums.pligg.com/versioncheck.php?product=simple_messaging';
	$module_info['homepage_url'] = 'http://forums.pligg.com/free-modules/21768-simple-messaging.html';
?>