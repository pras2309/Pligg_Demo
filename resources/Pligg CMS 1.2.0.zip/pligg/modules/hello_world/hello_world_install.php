<?php

	$module_info['name'] = 'Hello World';

	$module_info['desc'] = 'Welcomes the site Admin to Pligg. It should automatically disable itself after closing the automatic popup on the first admin homepage visit.';

	$module_info['version'] = 0.3;

	$module_info['update_url'] = 'http://forums.pligg.com/versioncheck.php?product=helloworld';

	$module_info['homepage_url'] = 'http://forums.pligg.com/pligg-modules/15515-hello-world.html';

	$module_info['requires'][] = array('admin_help_english', 0.1);

?>