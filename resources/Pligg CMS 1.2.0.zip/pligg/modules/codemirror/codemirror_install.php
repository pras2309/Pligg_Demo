<?php
	$module_info['name'] = 'CodeMirror Template Editor';
	$module_info['desc'] = 'CodeMirror is a JavaScript library that parses and styles code markup for the admin template editor.';
	$module_info['version'] = 0.1;
?>