<?php
	$module_info['name'] = 'Sidebar Comments';
	$module_info['desc'] = 'Displays the most recent comments in the sidebar';
	$module_info['version'] = 0.3;
?>
