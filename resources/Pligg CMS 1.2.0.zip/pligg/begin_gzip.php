<?php
ob_start("ob_gzhandler");
?>