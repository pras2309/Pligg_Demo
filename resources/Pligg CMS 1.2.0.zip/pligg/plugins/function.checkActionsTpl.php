<?php
function tpl_function_checkActionsTpl($params, $smarty)
    {
        check_actions_tpl($params['location'], $smarty);
    }
?>